matTr <-
function(z) sum(diag(z))
